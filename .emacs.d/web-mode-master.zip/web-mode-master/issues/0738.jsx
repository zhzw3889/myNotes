const AComponent = ({arg1, arg2, arg3}) => (
  <p>{arg1} {arg2} {arg3}</p>
)
