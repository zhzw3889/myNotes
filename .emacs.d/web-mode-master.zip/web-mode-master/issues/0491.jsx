function makeFoo (n) {
  return <Foo
           myAttr="foo"
           myProp={n}
         />
}
