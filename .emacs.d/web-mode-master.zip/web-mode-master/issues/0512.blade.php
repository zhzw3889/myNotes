<div>
  This is a test. {{ URL::action('someaction',
                                 [$arg]) }}
</div>
