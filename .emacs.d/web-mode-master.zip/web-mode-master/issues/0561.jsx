var test = function(){
  var n = 10;

  switch (n){
    case:
      console.log("test");
      break;
    case:
      break;
  }

});

AppDispatcher.register(function(action){
  var n = 10;

  switch (n){
    case 9:
      console.log(n);
      break;
    case 10:
      break;
  }
});
