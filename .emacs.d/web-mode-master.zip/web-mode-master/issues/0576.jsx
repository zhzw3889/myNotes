var MyClass = react.createClass({
  render: function() {
    var hello = <div>
      <hello></hello>
    </div>;
    return hello;
  }
});
