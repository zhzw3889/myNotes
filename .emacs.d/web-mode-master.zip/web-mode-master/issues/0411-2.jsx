var ColumnSelect = React.createClass({
  propTypes: {
    value: React.PropTypes.any,
    schema: React.PropTypes.object,
    onChange: React.PropTypes.func
  }
});
