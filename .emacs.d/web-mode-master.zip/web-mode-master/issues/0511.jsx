<div>
  {123}
  {x
</div>
