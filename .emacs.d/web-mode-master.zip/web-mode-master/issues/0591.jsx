import React, { Component, PropTypes } from 'react'

export default class MatchRow extends Component {
  render() {
    return (
      <a
          href="#"
          className="class-one class-two"
          type="button"
      >
      </a>

      <img
          src="someimage.jpg"
          className="thumbnail"
      />
    )
  }
}
