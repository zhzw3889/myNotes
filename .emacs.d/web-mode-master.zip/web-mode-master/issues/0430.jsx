var data = [
            {author: "Frodo baggins", text: "Eat apples"},
            {author: "Sam wise", text: "Please don't eat apples"},
            {author: "Sam wise", text: "Please don't eat apples"}
];
