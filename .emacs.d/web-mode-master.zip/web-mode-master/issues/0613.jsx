var ExampleComponent = React.createClass({
  render: function () {
    return (
      <div>
        <span><div></div></span>
      </div>
    )
  }
})
